package me.matl114.addon.containerscanner;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import me.matl114.accessors.access.ChunkAccess;
import me.matl114.events.Event;
import me.matl114.events.RenderListener;
import me.matl114.events.impl.Render3D;
import me.matl114.hacks.api.ModulePath;
import me.matl114.hacks.modules.inv.ChestHistory;
import me.matl114.hacks.modules.render.IRender2DColoredModule;
import me.matl114.hacks.utils.config.EntrySet;
import me.matl114.hacks.utils.config.Regex;
import me.matl114.hacks.utils.config.WrapColor;
import me.matl114.hacks.utils.render.RenderCollectors;
import me.matl114.managers.Configs;
import me.matl114.managers.config.FlagRef;
import me.matl114.managers.config.IntRef;
import me.matl114.managers.config.NBTRef;
import me.matl114.utils.CommonUtils;
import me.matl114.utils.RenderUtils;
import me.matl114.utils.render.RenderCollector;
import me.matl114.utils.world.ContainerPosition;
import me.matl114.versioned.api.VDrawContext;
import net.minecraft.class_1263;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2611;
import net.minecraft.class_2745;
import net.minecraft.class_2791;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_7923;

public final class ContainerScannerModule extends IRender2DColoredModule {
    public static ContainerScannerModule INSTANCE;

    private static final String ROOT = "container-scanner";

    public final IntRef radius = builder(hud.add("radius"), IntRef.TYPE)
            .defaultValue(32)
            .validator(Configs.intRange(8, 128))
            .build();

    public final IntRef refreshInterval = builder(hud.add("refresh-interval"), IntRef.TYPE)
            .defaultValue(20)
            .validator(Configs.intRange(1, 200))
            .build();

    public final IntRef maxLines = builder(hud.add("max-lines"), IntRef.TYPE)
            .defaultValue(10)
            .validator(Configs.intRange(1, 50))
            .build();

    public final FlagRef showContent =
            flagBuilder(hud.add("show-content")).defaultValue(true).build();

    public final FlagRef showCoordinates =
            flagBuilder(hud.add("show-coordinates")).defaultValue(true).build();

    public final FlagRef esp = flagBuilder(hud.add("esp")).defaultValue(true).build();

    public final FlagRef tracer =
            flagBuilder(hud.add("tracer")).defaultValue(false).build();

    public final NBTRef<WrapColor> espColor = builder(hud.add("esp-color"), WrapColor.class)
            .defaultValue(new WrapColor("#00FFAA"))
            .build();

    public final NBTRef<EntrySet<class_2591<?>>> typeFilter = builder(
                    hud.add("types"), EntrySet.<class_2591<?>>parameter())
            .defaultValue(new EntrySet<>(
                    new Regex("^(.*chest|barrel|.*box|hopper|furnace|smoker|blast_furnace|dispenser|dropper|crafter)$"),
                    class_7923.field_41181))
            .build();

    private final RenderCollector<class_238> boxCollector =
            RenderCollectors.createBoxCollector(true, false, false);
    private final RenderCollector<class_243> tracerCollector = RenderCollectors.createTracerCollector();

    private List<ContainerInfo> results = List.of();
    private int tickCounter;

    public ContainerScannerModule() {
        super("ContainerScanner");
        INSTANCE = this;
    }

    @Override
    protected ModulePath createRoot() {
        return makePath(ContainerScannerAddon.CONFIG, ROOT);
    }

    @Override
    public void registerAll() {
        super.registerAll();
        registerListener(RenderListener.getRender3DEvent(), this::onRender3D);
    }

    @Override
    public void onEnableModule() {
        super.onEnableModule();
        tickCounter = 0;
    }

    @Override
    public void onDisableModule() {
        super.onDisableModule();
        results = List.of();
        clearRender();
    }

    @Override
    public void onUpdate(Event<Void> event) {
        if (checkNull() || !enable.get()) {
            if (!results.isEmpty()) {
                results = List.of();
                clearRender();
            }
            return;
        }
        if (tickCounter++ % Math.max(1, refreshInterval.get()) != 0) {
            return;
        }
        scan();
    }

    @Override
    public void render2D(VDrawContext vdraw, float partialTicks) {
        if (checkNull()) {
            return;
        }
        List<ContainerInfo> list = results;
        if (list.isEmpty()) {
            drawText(vdraw, class_2561.method_43470("容器扫描: 未发现容器"));
            return;
        }
        drawText(vdraw, class_2561.method_43470("容器扫描 (" + list.size() + ")"));
        int max = Math.max(1, maxLines.get());
        int shown = 0;
        for (ContainerInfo info : list) {
            if (shown >= max) {
                drawText(vdraw, class_2561.method_43470("... +" + (list.size() - shown) + " 个"));
                break;
            }
            class_5250 line = class_2561.method_43473();
            line.method_10852(class_2561.method_43470(String.format(Locale.ROOT, "[%.1fm] ", info.distance())));
            line.method_10852(info.displayName());
            if (showCoordinates.get()) {
                line.method_10852(class_2561.method_43470(" " + info.pos().method_23854()));
            }
            if (showContent.get()) {
                if (info.contentSummary() != null) {
                    line.method_10852(class_2561.method_43470(" | "));
                    line.method_10852(info.contentSummary());
                } else {
                    line.method_10852(class_2561.method_43470(" | 未打开"));
                }
            }
            drawText(vdraw, line);
            shown++;
        }
    }

    private void scan() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        double radiusValue = radius.get();
        double radiusSq = radiusValue * radiusValue;
        class_243 playerPos = mc.field_1724.method_73189();
        int chunkRadius = Math.max(1, (int) Math.ceil(radiusValue / 16.0D));
        class_1923 center = mc.field_1724.method_31476();
        Map<ContainerPosition, ContainerInfo> unique = new LinkedHashMap<>();
        for (class_2791 chunk : CommonUtils.chunks(false)) {
            class_1923 chunkPos = chunk.method_12004();
            if (Math.abs(chunkPos.field_9181 - center.field_9181) > chunkRadius || Math.abs(chunkPos.field_9180 - center.field_9180) > chunkRadius) {
                continue;
            }
            for (Map.Entry<class_2338, class_2586> entry : ChunkAccess.of(chunk).blockEntityEntries()) {
                class_2338 pos = entry.getKey();
                class_2586 blockEntity = entry.getValue();
                if (!typeFilter.get().test(blockEntity.method_11017())) {
                    continue;
                }
                if (distanceSq(pos, playerPos) > radiusSq) {
                    continue;
                }
                ContainerPosition containerPosition = resolveContainerPosition(pos, blockEntity);
                ContainerInfo info = createInfo(pos, blockEntity, containerPosition, playerPos);
                ContainerInfo old = unique.get(containerPosition);
                if (old == null || info.distance() < old.distance()) {
                    unique.put(containerPosition, info);
                }
            }
        }
        List<ContainerInfo> found = new ArrayList<>(unique.values());
        found.sort(Comparator.comparingDouble(ContainerInfo::distance));
        results = List.copyOf(found);
        updateRender();
    }

    private ContainerPosition resolveContainerPosition(class_2338 pos, class_2586 blockEntity) {
        var state = blockEntity.method_11010();
        if (state.method_26204() instanceof class_2281 && state.method_11654(class_2281.field_10770) != class_2745.field_12569) {
            return ContainerPosition.resolve(mc.field_1687, pos);
        }
        return ContainerPosition.ofSingle(mc.field_1687, pos);
    }

    private ContainerInfo createInfo(
            class_2338 pos, class_2586 blockEntity, ContainerPosition containerPosition, class_243 playerPos) {
        double distance = Math.sqrt(distanceSq(pos, playerPos));
        class_2561 displayName = blockEntity.method_11010().method_26204().method_9518();
        ChestHistory history = ChestHistory.INSTANCE;
        ChestHistory.Entry cache = null;
        if (history != null) {
            if (blockEntity instanceof class_2611) {
                cache = history.getTrackedEnderChestEntry();
            } else {
                cache = history.getEntry(containerPosition);
            }
        }
        class_2561 summary = cache == null ? null : buildSummary(cache);
        return new ContainerInfo(
                pos, containerPosition, displayName, distance, summary, containerPosition.getBoundingBox());
    }

    private static double distanceSq(class_2338 pos, class_243 vec) {
        double dx = pos.method_10263() + 0.5D - vec.field_1352;
        double dy = pos.method_10264() + 0.5D - vec.field_1351;
        double dz = pos.method_10260() + 0.5D - vec.field_1350;
        return dx * dx + dy * dy + dz * dz;
    }

    private class_2561 buildSummary(ChestHistory.Entry entry) {
        class_1263 inventory = entry.getInventory();
        if (inventory == null || inventory.method_5439() == 0) {
            return class_2561.method_43470("空");
        }
        Map<class_1792, Integer> counts = new LinkedHashMap<>();
        Map<class_1792, class_1799> samples = new LinkedHashMap<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack == null || stack.method_7960()) {
                continue;
            }
            class_1792 item = stack.method_7909();
            counts.merge(item, stack.method_7947(), Integer::sum);
            samples.putIfAbsent(item, stack);
        }
        if (counts.isEmpty()) {
            return class_2561.method_43470("空");
        }
        class_5250 text = class_2561.method_43473();
        int shown = 0;
        for (Map.Entry<class_1792, Integer> entryCount : counts.entrySet()) {
            if (shown >= 3) {
                text.method_10852(class_2561.method_43470(" +" + (counts.size() - shown) + "种"));
                break;
            }
            if (shown > 0) {
                text.method_10852(class_2561.method_43470(", "));
            }
            text.method_10852(samples.get(entryCount.getKey()).method_7964());
            text.method_10852(class_2561.method_43470(" x" + entryCount.getValue()));
            shown++;
        }
        return text;
    }

    private void updateRender() {
        clearRender();
        int color = espColor.get().withAlpha(180);
        for (ContainerInfo info : results) {
            boxCollector.submit(info.box(), color);
            tracerCollector.submit(info.containerPosition().getCenterPosition(), color);
        }
    }

    private void clearRender() {
        boxCollector.clear();
        tracerCollector.clear();
    }

    private void onRender3D(Event<Render3D> event) {
        if (!enable.get() || checkNull()) {
            return;
        }
        boolean drawEsp = esp.get();
        boolean drawTracer = tracer.get();
        if (!drawEsp && !drawTracer) {
            return;
        }
        class_4587 stack = event.context().stack();
        boolean started = RenderUtils.startDrawVirtual(stack);
        try {
            if (drawEsp) {
                boxCollector.render3D(stack, event.context().partialTicks());
            }
            if (drawTracer) {
                tracerCollector.render3D(stack, event.context().partialTicks());
            }
        } finally {
            if (started) {
                RenderUtils.stopDrawVirtual(stack);
            }
        }
    }

    public record ContainerInfo(
            class_2338 pos,
            ContainerPosition containerPosition,
            class_2561 displayName,
            double distance,
            class_2561 contentSummary,
            class_238 box) {}
}
